#!/system/bin/sh
MODDIR=${0%/*}
REPORT="$MODDIR/K70Turbo_V2_report.txt"
DOWNLOAD="/sdcard/Download/K70Turbo_V2_report.txt"

# READ ONLY: no writes to sysfs/procfs, governors, frequencies, voltage,
# thermal limits, scheduler controls, or Android system settings.

C_RESET='\033[0m'
C_CYAN='\033[96m'
C_GREEN='\033[92m'
C_YELLOW='\033[93m'
C_DIM='\033[90m'
C_WHITE='\033[97m'

line() { printf '%b\n' "${C_DIM}────────────────────────────────────────${C_RESET}"; }
title() { printf '\n%b\n' "${C_CYAN}  $*${C_RESET}"; }
item() { printf '%b\n' "${C_WHITE}  $*${C_RESET}"; }
good() { printf '%b\n' "${C_GREEN}  $*${C_RESET}"; }
warn() { printf '%b\n' "${C_YELLOW}  $*${C_RESET}"; }
readval() { [ -r "$1" ] && cat "$1" 2>/dev/null || printf 'N/A'; }

mkdir -p /sdcard/Download 2>/dev/null

# Build a detailed report first.
{
    echo "K70 Turbo 性能监控台 V2 - 只读检测报告"
    echo "生成时间： $(date 2>/dev/null)"
    echo "未修改任何硬件或系统调校参数。"
    echo
    echo "[设备信息]"
    echo "制造商： $(getprop ro.product.manufacturer)"
    echo "型号： $(getprop ro.product.model)"
    echo "设备代号： $(getprop ro.product.device)"
    echo "安卓版本： $(getprop ro.build.version.release)"
    echo "SDK版本： $(getprop ro.build.version.sdk)"
    echo "系统版本： $(getprop ro.build.display.id)"
    echo "内核： $(uname -a 2>/dev/null)"
    echo
    echo "[CPU 在线状态]"
    echo "在线 CPU： $(readval /sys/devices/system/cpu/online)"
    echo
    echo "[CPU 调频策略]"
    FOUND=0
    for P in /sys/devices/system/cpu/cpufreq/policy*; do
        [ -d "$P" ] || continue
        FOUND=1
        echo "-- $P"
        for F in related_cpus affected_cpus scaling_driver scaling_governor scaling_available_governors scaling_min_freq scaling_max_freq cpuinfo_min_freq cpuinfo_max_freq scaling_cur_freq; do
            [ -r "$P/$F" ] && echo "$F: $(cat "$P/$F" 2>/dev/null)"
        done
    done
    [ "$FOUND" = "1" ] || echo "未发现可读取的 CPU 调频策略。"
    echo
    echo "[GPU / 其他设备调频]"
    FOUND=0
    for D in /sys/class/devfreq/*; do
        [ -d "$D" ] || continue
        FOUND=1
        echo "-- $D"
        for F in name governor available_governors cur_freq min_freq max_freq available_frequencies; do
            [ -r "$D/$F" ] && echo "$F: $(cat "$D/$F" 2>/dev/null)"
        done
    done
    [ "$FOUND" = "1" ] || echo "未发现可读取的设备调频节点。"
    echo
    echo "[内存信息]"
    grep -E '^(MemTotal|MemFree|MemAvailable|Buffers|Cached|SwapTotal|SwapFree):' /proc/meminfo 2>/dev/null
    echo
    echo "[ZRAM 压缩内存]"
    for Z in /sys/block/zram*; do
        [ -e "$Z" ] || continue
        echo "$(basename "$Z"): disksize=$(readval "$Z/disksize") mm_stat=$(readval "$Z/mm_stat")"
    done
    echo
    echo "[温度传感器]"
    for T in /sys/class/thermal/thermal_zone*; do
        [ -d "$T" ] || continue
        echo "$(basename "$T"): type=$(readval "$T/type") temp_raw=$(readval "$T/temp")"
    done
    echo
    echo "[调度器信息]"
    for F in /sys/kernel/debug/sched_features /sys/kernel/debug/sched/tunables /proc/sys/kernel/sched_latency_ns /proc/sys/kernel/sched_min_granularity_ns; do
        [ -r "$F" ] && { echo "-- $F"; head -n 80 "$F" 2>/dev/null; }
    done
    echo
    echo "[存储设备调度器]"
    for F in /sys/block/*/queue/scheduler; do
        [ -r "$F" ] && echo "$F: $(cat "$F" 2>/dev/null)"
    done
    echo
    echo "[报告结束]"
    echo "只读检测报告，未修改任何硬件设置。"
} > "$REPORT" 2>&1

# Terminal dashboard
printf '\033c'
printf '%b\n' "${C_CYAN}╔════════════════════════════════════════╗${C_RESET}"
printf '%b\n' "${C_CYAN}║       K70 TURBO PERFORMANCE V2         ║${C_RESET}"
printf '%b\n' "${C_CYAN}║             MONITOR CONSOLE            ║${C_RESET}"
printf '%b\n' "${C_CYAN}╚════════════════════════════════════════╝${C_RESET}"
good "● 只读监控模式"
item "不会修改任何硬件设置。"
line

title "01 设备信息"
item "型号： $(getprop ro.product.model)"
item "设备代号： $(getprop ro.product.device)"
item "安卓版本： $(getprop ro.build.version.release) / SDK $(getprop ro.build.version.sdk)"
item "系统版本： $(getprop ro.build.display.id)"
item "内核： $(uname -r 2>/dev/null)"

title "02 CPU 状态"
item "在线核心： $(readval /sys/devices/system/cpu/online)"
FOUND=0
for P in /sys/devices/system/cpu/cpufreq/policy*; do
    [ -d "$P" ] || continue
    FOUND=1
    item "$(basename "$P"): governor=$(readval "$P/scaling_governor")"
    item "  当前=$(readval "$P/scaling_cur_freq") kHz | 最低=$(readval "$P/scaling_min_freq") | 最高=$(readval "$P/scaling_max_freq")"
done
[ "$FOUND" = "1" ] || warn "没有可读取的 CPU 调频策略"

title "03 GPU / 设备调频"
FOUND=0
for D in /sys/class/devfreq/*; do
    [ -d "$D" ] || continue
    FOUND=1
    item "$(basename "$D"): governor=$(readval "$D/governor")"
    item "  当前=$(readval "$D/cur_freq") | 最低=$(readval "$D/min_freq") | 最高=$(readval "$D/max_freq")"
done
[ "$FOUND" = "1" ] || warn "没有可读取的设备调频节点"

title "04 内存 / ZRAM"
grep -E '^(MemTotal|MemAvailable|SwapTotal|SwapFree):' /proc/meminfo 2>/dev/null | while IFS=: read -r K V; do
    item "$K:$V"
done
for Z in /sys/block/zram*; do
    [ -e "$Z" ] || continue
    item "$(basename "$Z") disksize=$(readval "$Z/disksize")"
done

title "05 温度监控"
FOUND=0
for T in /sys/class/thermal/thermal_zone*; do
    [ -d "$T" ] || continue
    FOUND=1
    TYPE=$(readval "$T/type")
    RAW=$(readval "$T/temp")
    case "$RAW" in
        ''|N/A) DISPLAY="不可读取" ;;
        *[!0-9]*) DISPLAY="$RAW （原始值）" ;;
        *)
            if [ "$RAW" -gt 1000 ] 2>/dev/null; then
                DISPLAY="$((RAW / 1000)).$((RAW % 1000 / 100)) °C"
            else
                DISPLAY="$RAW （原始值，单位待确认）"
            fi
            ;;
    esac
    item "$(basename "$T") [$TYPE]: $DISPLAY"
done
[ "$FOUND" = "1" ] || warn "没有可读取的温度传感器"

title "06 调度器 / 存储"
for F in /sys/block/*/queue/scheduler; do
    [ -r "$F" ] && item "$(basename "$(dirname "$(dirname "$F")")"): $(cat "$F" 2>/dev/null)"
done
for F in /proc/sys/kernel/sched_latency_ns /proc/sys/kernel/sched_min_granularity_ns; do
    [ -r "$F" ] && item "$(basename "$F"): $(cat "$F" 2>/dev/null)"
done

line
good "监控状态：检测完成"
item "完整报告： $REPORT"
if cp "$REPORT" "$DOWNLOAD" 2>/dev/null; then
    good "已导出： $DOWNLOAD"
else
    warn "Download export 不可读取; report remains in module directory"
fi
line
item "再次点击模块的“操作 / Action”可刷新检测数据。"
exit 0
